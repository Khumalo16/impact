
javac numberrangesummarizer/Main.java
pass=0
i=0
echo
echo -e "\033[0;46mRunning tests: \033[0m"
prefix="../testcases/"
for TESTCASE in testcases/*.txt; do
  java -Xmx16m numberrangesummarizer.Main <$TESTCASE &>${TESTCASE%.txt}.out
  test=${TESTCASE#"$prefix"}
  if cmp --silent -- ${TESTCASE%.txt}.out ${TESTCASE%.txt}.suggested; then
    echo "Passed ${test}"
    pass=$(($pass + 1))
  else
    echo -e "\033[0;31mFailed $test \033[0m"
  fi

  i=$(($i + 1))
done

echo -e "\033[0;46mPassed: ($pass/$i)\033[0m"
rm numberrangesummarizer/*.class
cd ..
