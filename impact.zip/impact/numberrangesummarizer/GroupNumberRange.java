
package numberrangesummarizer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


/**
 * A class for implementing comma delimited lists,
 * a range of numbers that follow the same sequential
 * order are grouped together
 * 
 * All inputs are assumed to be valid, 
 * with each integer separated by a comma.
 */
public class GroupNumberRange implements NumberRangeSummarizer{

    @Override
    public Collection<Integer> collect(String input) {

        /**
         * Create and initialize an new arrayList-based collection.
         * 
         * The input consists of individual integers, separated by commas
         * and integers from the input collection are added 
         * to the arrayList-based collection
         */

        ArrayList<Integer> list = new ArrayList<>();
        String[] split = input.split(",");
        for (String spl : split) {
            list.add(Integer.parseInt(spl));
        }
        return list;
    }


    @Override
    public String summarizeCollection(Collection<Integer> input) {
        Iterator it = input.iterator();
        String answer = "";
        int current = (int) it.next();
        int count = 0;

        while(it.hasNext()) {
            int next = (int) it.next();

            // check whether the current and next integer are sequential

            if (current == next -1) {

                //add this current element if it's a lower bound

                if (count == 0) answer +=(", " + current);
                count++;
            } else {
                
                answer = addElement(answer, count, current);
                count = 0;
            }
            current = next;
        }

        // adding the last element depeding on the previous sequence.

        answer = addElement(answer, count, current);
        
        return answer.substring(2);
    }

    /**
     * Adding an element to the output based on the previous sequence.
     * 
     * Appending a dash "-" before this element indicates an upper boundary,
     * a comma "," otherwise.
     * 
     * @param answer a string to concatenate the element
     * @param count indicating whether is upper boundary or not
     * @param current the element to append in the output
     * @return the output with appended new element
     */
    private String addElement(String answer, int count, int current) {

        if (count < 2) {
            answer += (", "+current);
        } else {
            answer += ("-" + current);
        }
        return answer;
    }
}
