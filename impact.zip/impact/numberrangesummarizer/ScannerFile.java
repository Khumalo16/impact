package numberrangesummarizer;

public interface ScannerFile {
  /**
   * Scanning the file input
   * 
   */
  public void scanner();

  /**
   * Getting the total number of testcases
   * 
   * @param line the line contains number of testcases
   * @return total number of testcases
   */
  public int testcases(String line);

  /**
   * Getting the list from input,
   * The method also calculate the summarized list to get final output
   * 
   * @param line line that contains input list
   */
  public void readList(String line);
}
