package numberrangesummarizer;

/**
 * A main class to drive the pragram
 */
public class Main {
    public static void main(String[] args) {
        new ReadFileNSR();
    }
}


