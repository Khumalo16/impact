package numberrangesummarizer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Reading input from the file.
 * 
 */
public class ReadFileNSR implements ScannerFile {

    /**
     * An object that wrap an instance of GroupNumberRange 
     * and request all applicable methods for group summary range class
     */
    protected GroupNumberRange nrs;

    /**
     * Total number of testcases from the input
     */
    private int TEST_CASES;

    /**
     * A counter that counts the number of test cases that have been processed so far 
     * and this counter is used to displays the number of tests that have been executed
     */
    private int countNumTest = 0;

    /**
     * Constructs a new ReadFileNSR to scan the input 
     * and runs the summarized list
     */
    public ReadFileNSR() {

        this.nrs = new GroupNumberRange();
        scanner();
    }

    @Override
    public void scanner() {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            
            // loop until the end of the number of test cases line has been reached.

            while (true) {
                String line = br.readLine();
                if (line.trim().length() > 0) {
                    TEST_CASES = testcases(line);
                    break;
                }
            }

            // loop until all the testcases has been completed.

            while (TEST_CASES > 0) {

                System.out.print((countNumTest + 1) + ": ");

                // loop until a testcases is processed.

                while (true) {

                    String input = br.readLine();

                    // check if the current line is not empty.

                    if (input.trim().length() > 0) {
                        readList(input);
                        break;
                    }
                }

                TEST_CASES--;
                countNumTest++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int testcases(String line) {
        return Integer.parseInt(line);
    }

    @Override
    public void readList(String input) {

        String out = nrs.summarizeCollection(nrs.collect(input));
        output(out);
    }

    /**
     * A helper method to printout the ouput
     * 
     * @param out the output
     */
    private void output(String out) {
        System.out.println(out);
    }
}
